import os
from app import create_app
from app.extensions import db

app = create_app()

@app.cli.command("init-db")
def init_db():
    with app.app_context():
        db.create_all()
    print("Database tables created.")

@app.cli.command("create-admin")
def create_admin():
    from app.models import User
    from werkzeug.security import generate_password_hash

    email = os.getenv("ADMIN_EMAIL")
    password = os.getenv("ADMIN_PASSWORD")

    if not email or not password or password == "CHANGE_ME_NOW":
        raise SystemExit("Set ADMIN_EMAIL and a strong ADMIN_PASSWORD first.")

    with app.app_context():
        user = User.query.filter_by(email=email.lower().strip()).first()
        if not user:
            user = User(email=email.lower().strip(), role="admin")
            db.session.add(user)
        user.role = "admin"
        user.password_hash = generate_password_hash(password)
        db.session.commit()
    print("Admin account ready.")
