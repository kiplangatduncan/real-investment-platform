# Real Investment Platform — Production-Style Flask Starter

This is a production-oriented account/payment/investment-ledger starter for a lawful, partner-backed investment product.

It intentionally does NOT:
- create fake balances;
- promise a guaranteed 3-day/10% return;
- credit deposits from an unverified browser redirect.

Before accepting real customer money, connect the investment records to the appropriate licensed/authorized investment structure and complete KYC/AML, privacy, consumer-protection, payment, tax and regulatory work.

Stack: Flask, PostgreSQL, SQLAlchemy, Flask-Login, Flask-WTF/CSRF, Gunicorn, Requests.

Render:
Build command: pip install -r requirements.txt
Start command: gunicorn run:app

First database setup:
flask --app run.py init-db
flask --app run.py create-admin

Never commit .env or API secrets to GitHub.
