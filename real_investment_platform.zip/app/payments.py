import base64
import os
from datetime import datetime
import requests

def mpesa_access_token():
    env = os.getenv("MPESA_ENV", "sandbox")
    base = "https://sandbox.safaricom.co.ke" if env == "sandbox" else "https://api.safaricom.co.ke"
    r = requests.get(
        f"{base}/oauth/v1/generate?grant_type=client_credentials",
        auth=(os.environ["MPESA_CONSUMER_KEY"], os.environ["MPESA_CONSUMER_SECRET"]),
        timeout=30,
    )
    r.raise_for_status()
    return r.json()["access_token"]

def mpesa_stk_push(phone, amount, account_reference, description):
    env = os.getenv("MPESA_ENV", "sandbox")
    base = "https://sandbox.safaricom.co.ke" if env == "sandbox" else "https://api.safaricom.co.ke"

    shortcode = os.environ["MPESA_SHORTCODE"]
    passkey = os.environ["MPESA_PASSKEY"]
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    password = base64.b64encode(f"{shortcode}{passkey}{timestamp}".encode()).decode()

    payload = {
        "BusinessShortCode": shortcode,
        "Password": password,
        "Timestamp": timestamp,
        "TransactionType": "CustomerPayBillOnline",
        "Amount": int(amount),
        "PartyA": phone,
        "PartyB": shortcode,
        "PhoneNumber": phone,
        "CallBackURL": os.environ["MPESA_CALLBACK_URL"],
        "AccountReference": account_reference[:12],
        "TransactionDesc": description[:13],
    }

    r = requests.post(
        f"{base}/mpesa/stkpush/v1/processrequest",
        headers={"Authorization": f"Bearer {mpesa_access_token()}"},
        json=payload,
        timeout=30,
    )
    r.raise_for_status()
    return r.json()
