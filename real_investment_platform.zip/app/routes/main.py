from decimal import Decimal
from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from ..extensions import db
from ..models import Wallet, InvestmentPlan, Investment, Transaction
from ..ledger import debit_wallet, audit

bp = Blueprint("main", __name__)

@bp.get("/")
def index():
    return render_template("index.html")

@bp.get("/dashboard")
@login_required
def dashboard():
    wallets = Wallet.query.filter_by(user_id=current_user.id).all()
    investments = Investment.query.filter_by(user_id=current_user.id).order_by(Investment.created_at.desc()).limit(10).all()
    transactions = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.created_at.desc()).limit(10).all()
    return render_template("dashboard.html", wallets=wallets, investments=investments, transactions=transactions)

@bp.route("/invest", methods=["GET", "POST"])
@login_required
def invest():
    plans = InvestmentPlan.query.filter_by(active=True).all()
    if request.method == "POST":
        plan = db.session.get(InvestmentPlan, int(request.form["plan_id"]))
        amount = Decimal(request.form["amount"])
        if not plan or not plan.active:
            flash("Investment plan is not available.", "error")
            return redirect(url_for("main.invest"))
        if amount < plan.minimum_amount:
            flash(f"Minimum amount is {plan.minimum_amount} {plan.currency}.", "error")
            return redirect(url_for("main.invest"))

        try:
            debit_wallet(current_user.id, plan.currency, amount,
                         "investment_purchase", f"Investment in {plan.name}")
        except ValueError as exc:
            flash(str(exc), "error")
            return redirect(url_for("main.invest"))

        inv = Investment(user_id=current_user.id, plan_id=plan.id,
                         principal=amount, currency=plan.currency, status="active")
        db.session.add(inv)
        db.session.flush()
        audit(current_user.id, "investment_created", "investment", inv.id, f"{amount} {plan.currency}")
        db.session.commit()
        flash("Investment created and recorded in the ledger.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("invest.html", plans=plans)

@bp.get("/transactions")
@login_required
def transactions():
    rows = Transaction.query.filter_by(user_id=current_user.id).order_by(Transaction.created_at.desc()).all()
    return render_template("transactions.html", transactions=rows)
