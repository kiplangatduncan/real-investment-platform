from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user
from werkzeug.security import generate_password_hash
from ..extensions import db
from ..models import User

bp = Blueprint("auth", __name__)

@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        full_name = request.form.get("full_name", "").strip()
        phone = request.form.get("phone", "").strip()

        if len(password) < 10:
            flash("Use a password of at least 10 characters.", "error")
            return render_template("register.html")

        if User.query.filter_by(email=email).first():
            flash("An account with that email already exists.", "error")
            return render_template("register.html")

        user = User(email=email, password_hash=generate_password_hash(password),
                    full_name=full_name, phone=phone)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash("Account created. Complete verification before live investing.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("register.html")

@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            login_user(user)
            return redirect(url_for("main.dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("login.html")

@bp.post("/logout")
def logout():
    logout_user()
    return redirect(url_for("main.index"))
