from decimal import Decimal
from uuid import uuid4
from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from ..extensions import db
from ..models import Transaction
from ..ledger import get_wallet, audit
from ..payments import mpesa_stk_push

bp = Blueprint("payments", __name__, url_prefix="/payments")

@bp.route("/deposit", methods=["GET", "POST"])
@login_required
def deposit():
    if request.method == "POST":
        amount = Decimal(request.form["amount"])
        phone = request.form["phone"].strip()
        if amount <= 0:
            flash("Enter a valid amount.", "error")
            return render_template("deposit.html")

        ref = f"DEP-{uuid4().hex[:18].upper()}"
        result = mpesa_stk_push(phone, amount, ref, "Investment deposit")
        checkout_id = result.get("CheckoutRequestID")

        if not checkout_id:
            flash("Payment request could not be created.", "error")
            return render_template("deposit.html")

        wallet = get_wallet(current_user.id, "KES")
        tx = Transaction(user_id=current_user.id, wallet_id=wallet.id,
                         tx_type="deposit", status="pending",
                         amount=amount, currency="KES", reference=ref,
                         external_reference=checkout_id,
                         description="M-PESA STK deposit")
        db.session.add(tx)
        audit(current_user.id, "mpesa_stk_requested", "transaction", ref, checkout_id)
        db.session.commit()

        flash("M-PESA prompt sent. Balance changes only after verified callback/reconciliation.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("deposit.html")

@bp.post("/mpesa/callback")
def mpesa_callback():
    data = request.get_json(silent=True) or {}
    # Do NOT credit money from this payload until you implement provider-specific
    # validation/reconciliation and idempotency using the current Daraja docs.
    return jsonify({"ResultCode": 0, "ResultDesc": "Accepted"})

@bp.post("/withdraw")
@login_required
def withdraw():
    return jsonify({"error": "Withdrawal provider not configured"}), 501
