from functools import wraps
from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from ..models import User, Investment, Transaction, InvestmentPlan

bp = Blueprint("admin", __name__, url_prefix="/admin")

def admin_required(view):
    @wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if current_user.role != "admin":
            flash("Administrator access required.", "error")
            return redirect(url_for("main.dashboard"))
        return view(*args, **kwargs)
    return wrapped

@bp.get("/")
@admin_required
def dashboard():
    users = User.query.order_by(User.created_at.desc()).limit(100).all()
    investments = Investment.query.order_by(Investment.created_at.desc()).limit(100).all()
    transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(100).all()
    plans = InvestmentPlan.query.order_by(InvestmentPlan.id).all()
    return render_template("admin.html", users=users, investments=investments,
                           transactions=transactions, plans=plans)
