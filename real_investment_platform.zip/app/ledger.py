from decimal import Decimal
from uuid import uuid4
from .extensions import db
from .models import Wallet, Transaction, AuditLog

def get_wallet(user_id, currency):
    wallet = Wallet.query.filter_by(user_id=user_id, currency=currency).first()
    if not wallet:
        wallet = Wallet(user_id=user_id, currency=currency,
                        balance=Decimal("0.00"), available_balance=Decimal("0.00"))
        db.session.add(wallet)
        db.session.flush()
    return wallet

def credit_wallet(user_id, currency, amount, tx_type, description, external_reference=None):
    amount = Decimal(str(amount))
    if amount <= 0:
        raise ValueError("Credit amount must be positive.")
    wallet = get_wallet(user_id, currency)
    wallet.balance += amount
    wallet.available_balance += amount
    tx = Transaction(
        user_id=user_id, wallet_id=wallet.id, tx_type=tx_type,
        status="completed", amount=amount, currency=currency,
        reference=f"TX-{uuid4().hex[:20].upper()}",
        external_reference=external_reference,
        description=description,
    )
    db.session.add(tx)
    return tx

def debit_wallet(user_id, currency, amount, tx_type, description):
    amount = Decimal(str(amount))
    wallet = get_wallet(user_id, currency)
    if amount <= 0 or wallet.available_balance < amount:
        raise ValueError("Insufficient available balance.")
    wallet.balance -= amount
    wallet.available_balance -= amount
    tx = Transaction(
        user_id=user_id, wallet_id=wallet.id, tx_type=tx_type,
        status="completed", amount=amount, currency=currency,
        reference=f"TX-{uuid4().hex[:20].upper()}",
        description=description,
    )
    db.session.add(tx)
    return tx

def audit(actor_user_id, action, entity_type=None, entity_id=None, details=None):
    db.session.add(AuditLog(
        actor_user_id=actor_user_id,
        action=action,
        entity_type=entity_type,
        entity_id=str(entity_id) if entity_id is not None else None,
        details=details,
    ))
